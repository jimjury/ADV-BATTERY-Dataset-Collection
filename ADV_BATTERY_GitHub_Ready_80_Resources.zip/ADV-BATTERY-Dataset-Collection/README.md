# ADV·BATTERY｜公开电池数据资源索引

**开放数据，关联文献，服务电池科研。**

**80 条数据资源** · **76 条数据集** · **3 个数据门户 + 1 个工具** · **108 条文献/目录记录** · **69 条已登记数据—文献关联**

> **注意：** 本仓库只整理**数据集目录、研究标签和原始链接**，不托管第三方原始实验数据。开放访问不等于可任意转载或用于商业用途；下载与许可以发布方为准。链接**未全部逐一实时测试**。资料库快照：**2026-11-06**。

[English version](README_EN.md) · [按研究标签浏览](docs/TOPICS.md) · [80 条资源详情](docs/DATASET_DETAILS.md) · [108 条文献索引](docs/PAPERS.md) · [来源与使用说明](NOTICE.md)

## 目录

1. [新手如何使用](#新手如何使用)
2. [完整资源目录](#完整资源目录)
3. [按研究方向查找](#按研究方向查找)
4. [来源与核验说明](#来源与核验说明)
5. [参与维护与更新](#参与维护与更新)

## 新手如何使用

1. 在下表按机构、数据名称或 **SOC / SOH / RUL** 等标签寻找资源。
2. 点击“**数据入口**”到原始仓库；部分链接是资料页或需要单独申请，并非可直接下载的 ZIP。
3. 阅读相关论文，核对电池类型、实验条件、数据版本及许可证，再用于科研。

## 完整资源目录

| 序号 | 数据集 / 资源名称 | 发布机构 | 年份 | 类型 | 研究标签 | 数据入口 | 关联文献 |
|---:|---|---|---:|---|---|---|---|
| 01 | [NASA PCoE 锂离子电池老化数据集](docs/DATASET_DETAILS.md#dataset-01) | NASA Ames Research Center | 2007 | 数据集 | [SOH](docs/TOPICS.md#soh) · [RUL](docs/TOPICS.md#rul) · [EIS](docs/TOPICS.md#eis) | [数据入口](<https://phm-datasets.s3.amazonaws.com/NASA/5.+Battery+Data+Set.zip>) | [Prognostics Methods for Battery Health Monitori…](<https://doi.org/10.1109/TIM.2008.2005965>) |
| 02 | [NASA 随机工况电池使用数据集](docs/DATASET_DETAILS.md#dataset-02) | NASA Ames Research Center | 2014 | 数据集 | [SOH](docs/TOPICS.md#soh) · [RUL](docs/TOPICS.md#rul) | [数据入口](<https://phm-datasets.s3.amazonaws.com/NASA/11.+Randomized+Battery+Usage+Data+Set.zip>) | [Adaptation of an Electrochemistry-based Li-Ion…](<https://papers.phmsociety.org/index.php/phmconf/article/view/2480>) |
| 03 | [CALCE 电池研究开放数据](docs/DATASET_DETAILS.md#dataset-03) | University of Maryland · CALCE | 2011 | 数据门户 | [SOH](docs/TOPICS.md#soh) · [RUL](docs/TOPICS.md#rul) · [EIS](docs/TOPICS.md#eis) | [数据入口](<https://calce.umd.edu/data>) | [Prognostics of lithium-ion batteries based on D…](<https://doi.org/10.1016/j.jpowsour.2011.08.040>) |
| 04 | [MATR 早期循环寿命预测数据集](docs/DATASET_DETAILS.md#dataset-04) | MIT · Stanford · Toyota Research Institute | 2019 | 数据集 | [RUL](docs/TOPICS.md#rul) · [FAST](docs/TOPICS.md#fast) | [数据入口](<https://data.matr.io/1/projects/5c48dd2bc625d700019f3204>) | [Data-driven prediction of battery cycle life be…](<https://doi.org/10.1038/s41560-019-0356-8>) |
| 05 | [MATR 闭环极快充优化数据集](docs/DATASET_DETAILS.md#dataset-05) | Stanford · MIT · Toyota Research Institute | 2020 | 数据集 | [FAST](docs/TOPICS.md#fast) · [RUL](docs/TOPICS.md#rul) | [数据入口](<https://data.matr.io/1/projects/5d80e633f405260001c0b60a>) | [Closed-loop optimization of fast-charging proto…](<https://doi.org/10.1038/s41586-020-1994-5>) |
| 06 | [Oxford 电池退化数据集 1](docs/DATASET_DETAILS.md#dataset-06) | University of Oxford | 2017 | 数据集 | [SOH](docs/TOPICS.md#soh) · [RUL](docs/TOPICS.md#rul) | [数据入口](<https://ora.ox.ac.uk/objects/uuid:03ba4b01-cfed-46d3-9b1a-7d4a7bdf6fac>) | [Degradation diagnostics for lithium ion cells](<https://doi.org/10.1016/j.jpowsour.2016.12.121>) |
| 07 | [Oxford 能源交易电池退化数据集](docs/DATASET_DETAILS.md#dataset-07) | University of Oxford | 2020 | 数据集 | [SOH](docs/TOPICS.md#soh) | [数据入口](<https://ora.ox.ac.uk/objects/uuid:9aae61af-2949-49f1-8ad5-6aea448979e5>) | [Unlocking extra value from grid batteries using…](<https://doi.org/10.1016/j.jpowsour.2020.229355>) |
| 08 | [Cambridge 电池阻抗谱退化数据集](docs/DATASET_DETAILS.md#dataset-08) | University of Cambridge · Newcastle University | 2020 | 数据集 | [EIS](docs/TOPICS.md#eis) · [SOH](docs/TOPICS.md#soh) | [数据入口](<https://zenodo.org/records/3633835>) | [Identifying degradation patterns of lithium ion…](<https://doi.org/10.1038/s41467-020-15235-7>) |
| 09 | [同济大学电压弛豫容量估计数据集](docs/DATASET_DETAILS.md#dataset-09) | Tongji University · KIT · UBC | 2022 | 数据集 | [SOH](docs/TOPICS.md#soh) | [数据入口](<https://zenodo.org/records/6379166>) | [Data-driven capacity estimation of commercial l…](<https://doi.org/10.1038/s41467-022-29837-w>) |
| 10 | [RWTH 电池退化轨迹数据集](docs/DATASET_DETAILS.md#dataset-10) | RWTH Aachen University · ISEA | 2021 | 数据集 | [SOH](docs/TOPICS.md#soh) · [RUL](docs/TOPICS.md#rul) | [数据入口](<https://github.com/isea-rwth-aachen/battery-degradation-trajectory-prediction>) | [One-shot battery degradation trajectory predict…](<https://doi.org/10.1016/j.jpowsour.2021.230024>) |
| 11 | [XJTU 电池退化数据集](docs/DATASET_DETAILS.md#dataset-11) | Xi’an Jiaotong University | 2024 | 数据集 | [SOH](docs/TOPICS.md#soh) · [RUL](docs/TOPICS.md#rul) | [数据入口](<https://zenodo.org/records/10963339>) | [Physics-informed neural network for lithium-ion…](<https://doi.org/10.1038/s41467-024-48779-z>) |
| 12 | [Imperial 21700 电芯综合循环老化数据](docs/DATASET_DETAILS.md#dataset-12) | Imperial College London | 2024 | 数据集 | [SOH](docs/TOPICS.md#soh) | [数据入口](<https://zenodo.org/records/10637534>) | [Lithium-ion battery degradation: comprehensive…](<https://doi.org/10.1016/j.jpowsour.2024.234185>) |
| 13 | [Imperial 硅石墨电极退化数据](docs/DATASET_DETAILS.md#dataset-13) | Imperial College London | 2022 | 数据集 | [SOH](docs/TOPICS.md#soh) | [数据入口](<https://zenodo.org/records/7235858>) | [Lithium-ion battery degradation: measuring rapi…](<https://doi.org/10.1021/acsaem.2c02047>) |
| 14 | [Battery Archive 跨机构电池数据库](docs/DATASET_DETAILS.md#dataset-14) | Sandia National Laboratories · DOE | 2023 | 数据门户 | [SOH](docs/TOPICS.md#soh) · [RUL](docs/TOPICS.md#rul) | [数据入口](<https://www.batteryarchive.org/>) | — |
| 15 | [工业级大软包电池 Discovery Learning 数据](docs/DATASET_DETAILS.md#dataset-15) | University of Michigan · NUS · Farasis Energy | 2026 | 数据集 | [RUL](docs/TOPICS.md#rul) | [数据入口](<https://zenodo.org/records/17654407>) | [Discovery Learning predicts battery cycle life…](<https://doi.org/10.1038/s41586-025-09951-7>) |
| 16 | [华中科技大学个性化健康预测数据](docs/DATASET_DETAILS.md#dataset-16) | Huazhong University of Science and Technology | 2022 | 数据集 | [SOH](docs/TOPICS.md#soh) | [数据入口](<https://data.mendeley.com/datasets/nsc7hnsg4s/2>) | [Real-time personalized health status prediction…](<https://doi.org/10.1039/D2EE01676A>) |
| 17 | [Panasonic 18650PF 动态工况数据](docs/DATASET_DETAILS.md#dataset-17) | McMaster University · University of Wisconsin–Madison | 2018 | 数据集 | [SOC](docs/TOPICS.md#soc) | [数据入口](<https://data.mendeley.com/datasets/wykht8y7tg/1>) | [Long Short-Term Memory Networks for Accurate St…](<https://doi.org/10.1109/TIE.2017.2787586>) |
| 18 | [清华大学大规模电动车实车充电数据](docs/DATASET_DETAILS.md#dataset-18) | Tsinghua University | 2024 | 数据集 | [SOH](docs/TOPICS.md#soh) · [FIELD](docs/TOPICS.md#field) | [数据入口](<https://data.mendeley.com/datasets/mcsh4hnb8b/1>) | [Towards real-world state of health estimation:…](<https://doi.org/10.1016/j.etran.2024.100361>) |
| 19 | [机械诱发热失控实验数据](docs/DATASET_DETAILS.md#dataset-19) | Oak Ridge National Laboratory · Sandia National Laboratories | 2023 | 数据集 | [SAFETY](docs/TOPICS.md#safety) | [数据入口](<https://data.mendeley.com/datasets/sn2kv34r4h/2>) | [Mechanically induced thermal runaway severity a…](<https://doi.org/10.1016/j.est.2023.106798>) |
| 20 | [LG HG2 动态工况 SOC 数据](docs/DATASET_DETAILS.md#dataset-20) | McMaster University | 2018 | 数据集 | [SOC](docs/TOPICS.md#soc) | [数据入口](<https://data.mendeley.com/datasets/b5mj79w5w9/2>) | [Li-ion Battery SOC Estimation Using Long Short-…](<https://doi.org/10.1109/ITEC.2019.8790543>) |
| 21 | [Stanford 二次寿命电池长期运行数据](docs/DATASET_DETAILS.md#dataset-21) | Stanford University | 2024 | 数据集 | [SOH](docs/TOPICS.md#soh) | [数据入口](<https://osf.io/8jnr5/overview>) | [Second-life lithium-ion battery aging dataset b…](<https://doi.org/10.1016/j.dib.2024.111046>) |
| 22 | [多化学体系随机电流退化数据](docs/DATASET_DETAILS.md#dataset-22) | Aalto University · VTT | 2025 | 数据集 | [SOH](docs/TOPICS.md#soh) | [数据入口](<https://etsin.fairdata.fi/dataset/f60a7388-99b6-4637-96d5-8610a7f71612/data>) | [Dataset of lithium-ion cell degradation under r…](<https://doi.org/10.1016/j.dib.2025.111531>) |
| 23 | [280 Ah 方形磷酸铁锂热—老化数据](docs/DATASET_DETAILS.md#dataset-23) | University of Bath | 2026 | 数据集 | [MODEL](docs/TOPICS.md#model) · [SOH](docs/TOPICS.md#soh) | [数据入口](<https://zenodo.org/records/20813753>) | [280 Ah prismatic LFP cell: characterisation and…](<https://doi.org/10.5281/zenodo.20813753>) (数据记录) |
| 24 | [长安 300 辆新能源汽车全生命周期实车数据](docs/DATASET_DETAILS.md#dataset-24) | 智能汽车安全技术全国重点实验室 | 2025 | 数据集 | [SOC](docs/TOPICS.md#soc) · [SOH](docs/TOPICS.md#soh) · [FIELD](docs/TOPICS.md#field) | [数据入口](<https://ivstskl.changan.com.cn/?p=2697>) | [Multi-modal framework for battery state of heal…](<https://doi.org/10.1038/s41467-025-56485-7>) |
| 25 | [电动汽车锂离子电池 SOC 时序数据](docs/DATASET_DETAILS.md#dataset-25) | SR University | 2026 | 数据集 | [SOC](docs/TOPICS.md#soc) | [数据入口](<https://data.mendeley.com/datasets/7dkmgbspfg>) | [EV Lithium Ion Battery State of Charge Dataset](<https://doi.org/10.17632/7dkmgbspfg.2>) (数据记录) |
| 26 | [储能电站锂电池真实运行数据](docs/DATASET_DETAILS.md#dataset-26) | Zenodo 数据贡献者 | 2026 | 数据集 | [MODEL](docs/TOPICS.md#model) · [FIELD](docs/TOPICS.md#field) | [数据入口](<https://zenodo.org/records/18471156>) | [Energy Storage Power Station Lithium-Ion Batter…](<https://doi.org/10.5281/zenodo.18471156>) (数据记录) |
| 27 | [首尔大学动态工况退化路径数据](docs/DATASET_DETAILS.md#dataset-27) | Seoul National University | 2024 | 数据集 | [SOH](docs/TOPICS.md#soh) · [RUL](docs/TOPICS.md#rul) | [数据入口](<https://data.mendeley.com/datasets/h2y7mj4kt7/2>) | [Degradation path prediction of lithium-ion batt…](<https://doi.org/10.1039/D4EE04787G>) |
| 28 | [首尔大学负极空间退化诊断数据](docs/DATASET_DETAILS.md#dataset-28) | Seoul National University | 2025 | 数据集 | [SOH](docs/TOPICS.md#soh) | [数据入口](<https://data.mendeley.com/datasets/p5vbbytz3x/1>) | [Rapid and non-destructive diagnosis of lithium-…](<https://doi.org/10.1016/j.joule.2026.102343>) |
| 29 | [KIT 228 电芯综合老化与阻抗数据](docs/DATASET_DETAILS.md#dataset-29) | Karlsruhe Institute of Technology | 2024 | 数据集 | [SOH](docs/TOPICS.md#soh) · [EIS](docs/TOPICS.md#eis) | [数据入口](<https://zenodo.org/records/14555746>) | [Comprehensive battery aging dataset: capacity a…](<https://doi.org/10.1038/s41597-024-03831-x>) |
| 30 | [Panasonic NCR18650B 116 电芯多工况老化数据](docs/DATASET_DETAILS.md#dataset-30) | VIRTUAL VEHICLE Research GmbH | 2023 | 数据集 | [SOC](docs/TOPICS.md#soc) · [SOH](docs/TOPICS.md#soh) | [数据入口](<https://zenodo.org/records/7896429>) | [Ageing Data of Lithium-ion "Panasonic NCR18650B…](<https://doi.org/10.5281/zenodo.7896429>) (数据记录) |
| 31 | [NASA 加速电池寿命测试数据](docs/DATASET_DETAILS.md#dataset-31) | NASA Ames Research Center · University of Central Florida | 2023 | 数据集 | [RUL](docs/TOPICS.md#rul) | [数据入口](<https://www.nasa.gov/intelligent-systems-division/discovery-and-systems-health/pcoe/pcoe-data-set-repository/>) | [Prognosis of Li-ion Batteries Under Large Load…](<https://doi.org/10.36001/phmconf.2023.v15i1.3463>) |
| 32 | [Oxford 路径依赖电池退化数据 Part 1](docs/DATASET_DETAILS.md#dataset-32) | University of Oxford | 2020 | 数据集 | [SOH](docs/TOPICS.md#soh) | [数据入口](<https://ora.ox.ac.uk/objects/uuid:de62b5d2-6154-426d-bcbb-30253ddb7d1e>) | [Investigation of Path-Dependent Degradation in…](<https://doi.org/10.1002/batt.202000160>) |
| 33 | [Sandia 18650电芯温度相关退化原始数据](docs/DATASET_DETAILS.md#dataset-33) | Sandia National Laboratories | 2023 | 数据集 | [SOH](docs/TOPICS.md#soh) | [数据入口](<https://www.sandia.gov/energystoragesafety/rd-data-repository/>) | [Characterization of Cycle-Aged Commercial NMC a…](<https://doi.org/10.1149/1945-7111/ad1450>) |
| 34 | [Sandia 不同SOC下的加速量热ARC数据](docs/DATASET_DETAILS.md#dataset-34) | Sandia National Laboratories | 2021 | 数据集 | [SAFETY](docs/TOPICS.md#safety) | [数据入口](<https://www.sandia.gov/energystoragesafety/rd-data-repository/>) | [Investigating the Role of Energy Density in The…](<https://doi.org/10.1149/1945-7111/ac0699>) |
| 35 | [Sandia 正极材料反应热计算器](docs/DATASET_DETAILS.md#dataset-35) | Sandia National Laboratories | 2020 | 工具 | [SAFETY](docs/TOPICS.md#safety) | [数据入口](<https://www.sandia.gov/energystoragesafety/rd-data-repository/>) | [Review—Materials Science Predictions of Thermal…](<https://doi.org/10.1149/1945-7111/ab8fd9>) |
| 36 | [Sandia 钒液流电池单电池数据](docs/DATASET_DETAILS.md#dataset-36) | Sandia National Laboratories | 2020 | 数据集 | [MODEL](docs/TOPICS.md#model) | [数据入口](<https://www.sandia.gov/energystoragesafety/rd-data-repository/>) | [Open Data, Models, and Codes for Vanadium Redox…](<https://doi.org/10.1115/1.4044156>) |
| 37 | [Sandia 电芯ARC量热测试数据](docs/DATASET_DETAILS.md#dataset-37) | Sandia National Laboratories | 2019 | 数据集 | [SAFETY](docs/TOPICS.md#safety) | [数据入口](<https://www.sandia.gov/energystoragesafety/rd-data-repository/>) | [Multi-scale thermal stability study of commerci…](<https://doi.org/10.1016/j.jpowsour.2019.226777>) |
| 38 | [Sandia 电芯TGA-DSC测试数据](docs/DATASET_DETAILS.md#dataset-38) | Sandia National Laboratories | 2019 | 数据集 | [SAFETY](docs/TOPICS.md#safety) | [数据入口](<https://www.sandia.gov/energystoragesafety/rd-data-repository/>) | [Multi-scale thermal stability study of commerci…](<https://doi.org/10.1016/j.jpowsour.2019.226777>) |
| 39 | [Sandia 电芯滥用测试数据](docs/DATASET_DETAILS.md#dataset-39) | Sandia National Laboratories | 2017 | 数据集 | [SAFETY](docs/TOPICS.md#safety) | [数据入口](<https://www.sandia.gov/energystoragesafety/rd-data-repository/>) | [A Database for Comparative Electrochemical Perf…](<https://doi.org/10.1149/2.1701712jes>) |
| 40 | [Sandia 电芯循环测试数据](docs/DATASET_DETAILS.md#dataset-40) | Sandia National Laboratories | 2017 | 数据集 | [SOH](docs/TOPICS.md#soh) | [数据入口](<https://www.sandia.gov/energystoragesafety/rd-data-repository/>) | [A Database for Comparative Electrochemical Perf…](<https://doi.org/10.1149/2.1701712jes>) |
| 41 | [Sandia 电芯阻抗谱EIS测试数据](docs/DATASET_DETAILS.md#dataset-41) | Sandia National Laboratories | 2017 | 数据集 | [EIS](docs/TOPICS.md#eis) | [数据入口](<https://www.sandia.gov/energystoragesafety/rd-data-repository/>) | [A Database for Comparative Electrochemical Perf…](<https://doi.org/10.1149/2.1701712jes>) |
| 42 | [汽车锂离子电芯实际使用工况数据](docs/DATASET_DETAILS.md#dataset-42) | IEEE DataPort · Massimiliano Luzi | 2022 | 数据集 | [SOC](docs/TOPICS.md#soc) | [数据入口](<https://ieee-dataport.org/documents/automotive-li-ion-cell-usage-data-set>) | [Automotive Li-ion Cell Usage Data Set](<https://doi.org/10.21227/CE9Q-JR19>) |
| 43 | [两类锂离子电池退化数据](docs/DATASET_DETAILS.md#dataset-43) | Beijing Institute of Technology | 2023 | 数据集 | [SOH](docs/TOPICS.md#soh) | [数据入口](<https://data.mendeley.com/datasets/v8k6bsr6tf/1>) | [Deep learning to estimate lithium-ion battery s…](<https://doi.org/10.1038/s41467-023-38458-w>) |
| 44 | [保时捷 Taycan LG E66 电芯与模组快充测试数据](docs/DATASET_DETAILS.md#dataset-44) | McMaster University / Borealis | 2024 | 数据集 | [SOC](docs/TOPICS.md#soc) · [FAST](docs/TOPICS.md#fast) · [MODEL](docs/TOPICS.md#model) | [数据入口](<https://doi.org/10.5683/SP3/7JP3NM>) | [Experimental Performance Analysis of LG E-66 Ce…](<https://doi.org/10.1109/ITEC60657.2024.10599015>) |
| 45 | [CALCE INR18650-20R 多温度 OCV 与动态工况数据](docs/DATASET_DETAILS.md#dataset-45) | University of Maryland · CALCE | 2016 | 数据集 | [SOC](docs/TOPICS.md#soc) · [MODEL](docs/TOPICS.md#model) | [数据入口](<https://calce.umd.edu/battery-data>) | [Influence of different open circuit voltage tes…](<https://doi.org/10.1016/j.apenergy.2016.09.010>) |
| 46 | [LLiM 电池三项下游任务公开数据](docs/DATASET_DETAILS.md#dataset-46) | Shared E-bike Battery Consortium / Figshare | 2025 | 数据集 | [SOH](docs/TOPICS.md#soh) · [SAFETY](docs/TOPICS.md#safety) · [FIELD](docs/TOPICS.md#field) | [数据入口](<https://doi.org/10.6084/m9.figshare.28260095>) | [Large lithium-ion battery model for secure shar…](<https://doi.org/10.1038/s41467-025-63678-7>) |
| 47 | [Stanford INR21700-M50T 实车工况老化数据](docs/DATASET_DETAILS.md#dataset-47) | Stanford Energy Control Laboratory / Open Science Framework | 2022 | 数据集 | [SOH](docs/TOPICS.md#soh) · [RUL](docs/TOPICS.md#rul) · [EIS](docs/TOPICS.md#eis) | [数据入口](<https://osf.io/qsabn/>) | [Lithium-ion battery aging dataset based on elec…](<https://doi.org/10.1016/j.dib.2022.107995>) |
| 48 | [Stanford 12 电芯高功率 P42A 多温度特性数据](docs/DATASET_DETAILS.md#dataset-48) | Stanford Energy Control Lab / OSF | 2025 | 数据集 | [EIS](docs/TOPICS.md#eis) · [FAST](docs/TOPICS.md#fast) · [MODEL](docs/TOPICS.md#model) | [数据入口](<https://osf.io/9ceav/>) | [High-power lithium-ion battery characterization…](<https://doi.org/10.1038/s41597-025-05725-y>) |
| 49 | [Loughborough 长期二次寿命电池循环数据](docs/DATASET_DETAILS.md#dataset-49) | Loughborough University / Powervault | 2025 | 数据集 | [SOH](docs/TOPICS.md#soh) · [RUL](docs/TOPICS.md#rul) | [数据入口](<https://doi.org/10.17028/rd.lboro.28732490.v2>) | [Long-Term Sweat Testing Dataset for Second-Life…](<https://doi.org/10.1038/s41597-025-05360-7>) |
| 50 | [20 辆真实电动车充电容量衰退数据](docs/DATASET_DETAILS.md#dataset-50) | University of Electronic Science and Technology / BatICM GitHub | 2023 | 数据集 | [SOH](docs/TOPICS.md#soh) · [FIELD](docs/TOPICS.md#field) | [数据入口](<https://github.com/BatICM/battery-charging-data-of-on-road-electric-vehicles>) | [Prognostics of battery capacity based on chargi…](<https://doi.org/10.1016/j.apenergy.2023.120954>) |
| 51 | [西安交大数据驱动库仑计数 SOC 标定实验数据](docs/DATASET_DETAILS.md#dataset-51) | Xi’an Jiaotong University / Mendeley Data | 2020 | 数据集 | [SOC](docs/TOPICS.md#soc) · [MODEL](docs/TOPICS.md#model) | [数据入口](<https://data.mendeley.com/datasets/c5dxwn6w92/1>) | [A data-driven coulomb counting method for state…](<https://doi.org/10.1016/j.seta.2020.100752>) |
| 52 | [离线强化学习电动汽车能量管理论文源数据](docs/DATASET_DETAILS.md#dataset-52) | Beijing Institute of Technology / Nature Communications | 2025 | 数据集 | [MODEL](docs/TOPICS.md#model) · [FIELD](docs/TOPICS.md#field) | [数据入口](<https://pmc.ncbi.nlm.nih.gov/articles/instance/11929786/bin/41467_2025_58192_MOESM3_ESM.zip>) | [Data-driven energy management for electric vehi…](<https://doi.org/10.1038/s41467-025-58192-9>) |
| 53 | [北航 515 辆实车电池安全故障诊断数据](docs/DATASET_DETAILS.md#dataset-53) | Beihang University / Zenodo | 2024 | 数据集 | [SAFETY](docs/TOPICS.md#safety) · [FIELD](docs/TOPICS.md#field) | [数据入口](<https://zenodo.org/records/10656500>) | [Model-constrained deep learning for online faul…](<https://doi.org/10.1038/s41467-025-56832-8>) |
| 54 | [Oxford 电池数据与代码集合入口](docs/DATASET_DETAILS.md#dataset-54) | Oxford | — | 数据门户 | [SOH](docs/TOPICS.md#soh) · [RUL](docs/TOPICS.md#rul) | [数据入口](<https://battery-intelligence-lab.github.io/data-and-code/>) | — |
| 55 | [清华大学电芯级 SOH 实验数据](docs/DATASET_DETAILS.md#dataset-55) | Tsinghua University | 2024 | 数据集 | [SOH](docs/TOPICS.md#soh) | [数据入口](<https://1drv.ms/f/s!AuAiTLYEMUuKbLRMwP_d3RbUFs4?e=LL44SK>) | [Towards real-world state of health estimation,…](<https://doi.org/10.1016/j.etran.2024.100338>) |
| 56 | [山东大学多状态联合估计混合数据](docs/DATASET_DETAILS.md#dataset-56) | Shandong University | 2025 | 数据集 | [MODEL](docs/TOPICS.md#model) | [数据入口](<https://data.mendeley.com/datasets/dbwsn6t96j/1>) | [Large battery model for multi-state co-estimati…](<https://doi.org/10.1016/j.ensm.2026.104892>) |
| 57 | [山东大学退役电池分选数据](docs/DATASET_DETAILS.md#dataset-57) | Shandong University | 2025 | 数据集 | [SOH](docs/TOPICS.md#soh) · [RUL](docs/TOPICS.md#rul) | [数据入口](<https://zenodo.org/records/14859405>) | [Deep sorting of reused batteries for enabling l…](<https://doi.org/10.1016/j.xcrp.2025.102657>) |
| 58 | [上海交通大学缺数据健康预测资源](docs/DATASET_DETAILS.md#dataset-58) | Shanghai Jiaotong University | 2025 | 数据集 | [SOH](docs/TOPICS.md#soh) | [数据入口](<https://data.mendeley.com/datasets/vfd3f3srfk/2>) | [Battery health prognosis in data-deficient prac…](<https://doi.org/10.1016/j.xcrp.2025.102442>) |
| 59 | [Stanford 电池数据记录 68jkb7x6t4](docs/DATASET_DETAILS.md#dataset-59) | Stanford University | 2021 | 数据集 | [SOC](docs/TOPICS.md#soc) · [MODEL](docs/TOPICS.md#model) | [数据入口](<https://data.mendeley.com/datasets/68jkb7x6t4/3>) | — |
| 60 | [MIT/BIT 不确定未来工况退化数据](docs/DATASET_DETAILS.md#dataset-60) | MIT / Beijing Institute of Technology | 2021 | 数据集 | [RUL](docs/TOPICS.md#rul) | [数据入口](<https://data.mendeley.com/datasets/kw34hhw7xg/3>) | [Battery degradation prediction against uncertai…](<https://doi.org/10.1016/j.ensm.2022.05.007>) |
| 61 | [北京理工大学超短充电片段健康评估](docs/DATASET_DETAILS.md#dataset-61) | Beijing Institute of Technology | 2024 | 数据集 | [SOH](docs/TOPICS.md#soh) | [数据入口](<https://zenodo.org/records/14576042>) | [Smart Health Evaluation for Lithium-Ion Battery…](<https://doi.org/10.1002/advs.202503583>) |
| 62 | [Aalborg 电池数据记录 yz4pttm73n](docs/DATASET_DETAILS.md#dataset-62) | Aalborg University | 2023 | 数据集 | [SOH](docs/TOPICS.md#soh) | [数据入口](<https://data.mendeley.com/datasets/yz4pttm73n/2>) | — |
| 63 | [Bayreuth 电池数据记录 15755725](docs/DATASET_DETAILS.md#dataset-63) | University of Bayreuth | 2025 | 数据集 | [SOH](docs/TOPICS.md#soh) · [EIS](docs/TOPICS.md#eis) | [数据入口](<https://zenodo.org/records/15755725>) | — |
| 64 | [Darmstadt 实场电池在线监测与故障数据](docs/DATASET_DETAILS.md#dataset-64) | Technische Universitaet Darmstadt | 2024 | 数据集 | [SOH](docs/TOPICS.md#soh) · [SAFETY](docs/TOPICS.md#safety) · [FIELD](docs/TOPICS.md#field) | [数据入口](<https://zenodo.org/records/13715694>) | [Gaussian process-based online health monitoring…](<https://doi.org/10.1016/j.xcrp.2024.102258>) |
| 65 | [KIT FOBSS 模块化电池系统监测数据](docs/DATASET_DETAILS.md#dataset-65) | Karlsruhe Institute of Technology | 2023 | 数据集 | [MODEL](docs/TOPICS.md#model) | [数据入口](<https://www.radar-service.eu/radar/de/dataset/uabgQSNJZVAhKHgS>) | — |
| 66 | [KIT NMC/C-SiO 老化数据 V2 原始日志](docs/DATASET_DETAILS.md#dataset-66) | Karlsruhe Institute of Technology | 2024 | 数据集 | [SOH](docs/TOPICS.md#soh) · [EIS](docs/TOPICS.md#eis) | [数据入口](<https://radar.kit.edu/radar/en/dataset/kww7jv8ajuvchcah>) | [Comprehensive battery aging dataset: capacity a…](<https://doi.org/10.1038/s41597-024-03831-x>) |
| 67 | [Abhishek Bansal 电池数据记录 364p44vtj2](docs/DATASET_DETAILS.md#dataset-67) | Abhishek Bansal | 2023 | 数据集 | [SOH](docs/TOPICS.md#soh) | [数据入口](<https://data.mendeley.com/datasets/364p44vtj2/1>) | — |
| 68 | [NREL 快速直流脉冲诊断数据](docs/DATASET_DETAILS.md#dataset-68) | National Renewable Energy Laboratory | 2025 | 数据集 | [SOH](docs/TOPICS.md#soh) · [SOC](docs/TOPICS.md#soc) · [SAFETY](docs/TOPICS.md#safety) | [数据入口](<https://data.mendeley.com/datasets/ksc4sv46x6/1>) | [Searching for a Pulse: Evaluating the Use of Ra…](<https://doi.org/10.1149/1945-7111/addd50>) |
| 69 | [Seoul National 电池数据记录 zn82y35zr8](docs/DATASET_DETAILS.md#dataset-69) | Seoul National University | 2025 | 数据集 | [SOH](docs/TOPICS.md#soh) · [RUL](docs/TOPICS.md#rul) | [数据入口](<https://data.mendeley.com/datasets/zn82y35zr8/4>) | — |
| 70 | [McMaster 电池数据记录 9xyvy2njj3](docs/DATASET_DETAILS.md#dataset-70) | McMaster University | 2023 | 数据集 | [SOC](docs/TOPICS.md#soc) | [数据入口](<https://data.mendeley.com/datasets/9xyvy2njj3/2>) | — |
| 71 | [McMaster 电池数据记录 cp3473x7xv](docs/DATASET_DETAILS.md#dataset-71) | McMaster University | 2020 | 数据集 | [SOC](docs/TOPICS.md#soc) | [数据入口](<https://data.mendeley.com/datasets/cp3473x7xv/3>) | — |
| 72 | [Limerick 电池 SOH 机器学习对比数据线索](docs/DATASET_DETAILS.md#dataset-72) | University of Limerick | 2025 | 数据集 | [SOH](docs/TOPICS.md#soh) | [数据入口](<https://zenodo.org/records/15657829>) | [Advanced machine learning techniques for State-…](<https://doi.org/10.1016/j.electacta.2025.145988>) |
| 73 | [Colorado 电池电热耦合模型充电控制数据](docs/DATASET_DETAILS.md#dataset-73) | University of Colorado Colorado Springs | 2021 | 数据集 | [MODEL](docs/TOPICS.md#model) · [FAST](docs/TOPICS.md#fast) | [数据入口](<https://data.mendeley.com/datasets/p8kf893yv3/1>) | [Lithium-Ion Battery Charging Control Using a Co…](<https://doi.org/10.1109/APEC39645.2020.9124431>) |
| 74 | [Munich 多阶段锂电池老化数据](docs/DATASET_DETAILS.md#dataset-74) | Munich University of Applied Sciences | 2024 | 数据集 | [SOH](docs/TOPICS.md#soh) · [RUL](docs/TOPICS.md#rul) | [数据入口](<https://figshare.com/articles/dataset/Multi-Stage_Lithium_Ion_Battery_Aging_Study/25975315>) | [A multi-stage lithium-ion battery aging dataset…](<https://doi.org/10.1038/s41597-024-03859-z>) |
| 75 | [Bilkent 电池数据记录 14606633](docs/DATASET_DETAILS.md#dataset-75) | Bilkent University | 2025 | 数据集 | [SOH](docs/TOPICS.md#soh) · [EIS](docs/TOPICS.md#eis) | [数据入口](<https://zenodo.org/records/14606633>) | — |
| 76 | [HKUST 首周期小样本寿命异常数据](docs/DATASET_DETAILS.md#dataset-76) | Hong Kong University of Science and Technology | 2023 | 数据集 | [RUL](docs/TOPICS.md#rul) | [数据入口](<https://drive.google.com/drive/folders/1wMoXu-G9zC6CPyo-t742XNEkHYbPnWmb>) | [Detecting Abnormality of Battery Lifetime from…](<https://doi.org/10.1002/advs.202305315>) |
| 77 | [清华大学早期退化模式解耦数据](docs/DATASET_DETAILS.md#dataset-77) | Tsinghua University | 2024 | 数据集 | [SOH](docs/TOPICS.md#soh) · [RUL](docs/TOPICS.md#rul) | [数据入口](<https://zenodo.org/records/10715209>) | [Non-destructive degradation pattern decoupling…](<https://doi.org/10.1039/D4EE03839H>) |
| 78 | [Pavia/Trieste CALB 58Ah 方形电池工况数据](docs/DATASET_DETAILS.md#dataset-78) | University of Pavia / University of Trieste | 2025 | 数据集 | [SOC](docs/TOPICS.md#soc) · [EIS](docs/TOPICS.md#eis) · [MODEL](docs/TOPICS.md#model) | [数据入口](<https://data.mendeley.com/datasets/ycx459r5c3/2>) | [A dataset for large prismatic lithium-ion batte…](<https://doi.org/10.1016/j.dib.2025.111301>) |
| 79 | [HKUST BatteryLife 统一预处理寿命数据 V11](docs/DATASET_DETAILS.md#dataset-79) | Hong Kong University of Science and Technology | 2026 | 数据集 | [RUL](docs/TOPICS.md#rul) | [数据入口](<https://zenodo.org/records/19688272>) | [BatteryLife: A Comprehensive Dataset and Benchm…](<https://doi.org/10.1145/3711896.3737372>) |
| 80 | [CMU eVTOL 电动航空电池任务工况数据](docs/DATASET_DETAILS.md#dataset-80) | Carnegie Mellon University | 2023 | 数据集 | [MODEL](docs/TOPICS.md#model) · [RUL](docs/TOPICS.md#rul) | [数据入口](<https://kilthub.cmu.edu/articles/dataset/eVTOL_Battery_Dataset/14226830/2>) | [A battery dataset for electric vertical takeoff…](<https://doi.org/10.1038/s41597-023-02180-5>) |

## 按研究方向查找

| 标签 | 相关资源数 | 研究方向 |
|---|---:|---|
| [SOC](docs/TOPICS.md#soc) | 14 | SOC 估计 |
| [SOH](docs/TOPICS.md#soh) | 46 | SOH 估计 |
| [RUL](docs/TOPICS.md#rul) | 23 | 剩余寿命 |
| [EIS](docs/TOPICS.md#eis) | 11 | 电化学阻抗谱 |
| [FAST](docs/TOPICS.md#fast) | 5 | 快充 |
| [FIELD](docs/TOPICS.md#field) | 8 | 实车数据 |
| [MODEL](docs/TOPICS.md#model) | 14 | 电池建模 |
| [SAFETY](docs/TOPICS.md#safety) | 10 | 电池安全 |

_同一资源可以有多个研究标签；标签来自现有资料库，不代表已经核对所有原始文件是否具备相应字段。_

## 来源与核验说明

- **80 条资源**包括 **76 条数据集条目**和 **4 个资料入口**（3 个门户、1 个工具），不是 80 份打包的数据文件。
- **108 条文献/目录记录**包含研究论文、综述、数据集正式记录等，并不全是同行评议论文。
- **69 条显式关联**保留了原资料库中的审核状态，并非全部经过独立验证。
- 整合了 [PythoniLover 的 41 条来源目录](https://github.com/PythoniLover/battery-dataset-collection)，其中 **14 条匹配原记录、27 条新增**，详见 [来源对应表](docs/SOURCE_41_MAPPING.md)。
- 某些资源仅提供元数据页面、索引或受限入口；论文年份和数据版本年份也可能不同。详见 [来源、免责声明与许可](NOTICE.md)。

## 参与维护与更新

本目录由 ADV·BATTERY 正式资料库导出。提交新资源请参考 [贡献指南](CONTRIBUTING.md)；同步本地最新版请参考 [维护说明](docs/MAINTENANCE.md)，并使用 `python scripts/build_public_index.py --check` 和 `python scripts/validate_public_index.py` 验证。
