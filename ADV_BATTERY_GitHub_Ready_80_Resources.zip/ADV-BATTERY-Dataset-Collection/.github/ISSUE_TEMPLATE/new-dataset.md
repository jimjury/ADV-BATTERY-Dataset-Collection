---
name: "New battery dataset / 新数据集"
about: "Suggest a new public battery data resource"
title: "[Dataset] "
labels: []
assignees: []
---

### Dataset title / 数据集名称

### Original provider / 发布机构

### Original data landing page / 官方网址

### Dataset DOI (if available; no guesses) / 数据集 DOI

### Related publication and DOI / 相关论文

### Tasks and evidence / SOC, SOH, RUL, EIS, safety, etc.

### Chemistry, capacity, temperature and protocols (only if source-backed) / 电池体系与实验条件

### Licence / 使用条件（如已确认）

### Why is this resource useful? / 推荐理由
